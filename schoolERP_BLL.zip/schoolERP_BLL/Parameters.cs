﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace schoolERP_BLL
{
  
  public  class Parameters
    {

        public string val { get; set; }
        public string val1 { get; set; }
        public string val2 { get; set; }
        public string val3 { get; set; }
        public string val4 { get; set; }
        public string val5 { get; set; }
        public string val6 { get; set; }
        public string val7 { get; set; }
        public string val8 { get; set; }
        public string val9 { get; set; }
        public string val10 { get; set; }
        public string val11 { get; set; }
        public string val12 { get; set; }
        public string val13 { get; set; }
        public string val14 { get; set; }
        public string val15 { get; set; }
        public string val16 { get; set; }
        public string val17 { get; set; }
        public string val18 { get; set; }
        public string val19 { get; set; }
    }
}
